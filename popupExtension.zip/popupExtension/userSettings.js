localStorage.setItem('num-of-topics', '7');
localStorage.setItem('num-of-reviews', '1000')
localStorage.setItem('query', JSON.stringify({}));
localStorage.setItem('data-in-cache', JSON.stringify({ 'appid': 0, 'cursor': '*', 'reviews': [] }));